import matplotlib.pyplot as plt
import os.path
import numpy as np
# Get the directory name for data files
directory = os.path.dirname(os.path.abspath(__file__))

# Open the file
datafile= open(directory + '\\National Debt and Military Spending.csv','r')
data = datafile.readlines()

Federal_Debt=[]
Military_Spending=[]
Years=[]
for line in data[1:]:
    Fyear, Fdebt, Mspending = line.split(',')
    Federal_Debt.append(int(Fdebt))
    Military_Spending.append(int(Mspending))
    Years.append(int(Fyear))
#Close File

# Plot on one set of axes.

fig, ax = plt.subplots(1,2)

ax[0].scatter(Years, Federal_Debt, color='red')
ax[0].set_title('National Debt')
ax[0].set_xlabel('Years')
ax[0].set_ylabel('U.S. Dollars (In billions)')

ax[1].scatter(Years, Military_Spending, color='blue')
ax[1].set_title('Military Spending')
ax[1].set_xlabel('Years')
ax[1].set_ylabel('U.S. Dollars')

fig.show()